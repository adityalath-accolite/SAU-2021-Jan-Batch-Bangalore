import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Word } from '../Models/word';

@Injectable()
export class WordService {

  GET_ALL = "/word/getAll";
  SAVE = "/word/save";
  DELETE_BY_ID = "/word/delete/";

  constructor(private http: HttpClient) { }

  getAll(): Observable<any>{
    return this.http.get(this.GET_ALL);
  }

  addWord(payload: Word): Observable<any>{
    return this.http.post(this.SAVE, payload);
  }

  deleteWord(id: Number): Observable<any>{
    return this.http.delete(this.DELETE_BY_ID + id)
  }

}
