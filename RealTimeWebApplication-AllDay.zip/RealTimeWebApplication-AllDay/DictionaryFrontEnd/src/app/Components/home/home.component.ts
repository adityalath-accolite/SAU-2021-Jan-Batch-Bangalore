import { Component, OnInit } from '@angular/core';
import { WordService } from '../../Services/word.service';
import { Word } from '../../Models/word';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  words: Array<Word> = [];
  
  editableWord!: Word;

  constructor(private service: WordService) { }

  ngOnInit(): void {
    this.service.getAll().subscribe(resp => {
      this.words = resp;
      this.words = this.words.sort((a,b) => a.word.localeCompare(b.word));
    });
    console.log(this.words);
  }

  onEdit(word:Word):void{
    this.editableWord = word;
  }

  updateWord($event: any):void{
    console.log($event);
    this.service.deleteWord($event.id).subscribe(
      resp => {
        if(resp)
        {
          this.words = this.words.filter(old => old.id != $event.id);  
        } 
      }
    )
    this.service.addWord($event).subscribe(resp => this.words.push(resp));
  }

  onDelete(word:Word):void{
    this.service.deleteWord(word.id).subscribe(resp => {
      if(resp)
      {
        this.words = this.words.filter(old => old.id != word.id);  
        //for real-time performance, else we have to refresh to see the change
      } 
    })
  }

}
