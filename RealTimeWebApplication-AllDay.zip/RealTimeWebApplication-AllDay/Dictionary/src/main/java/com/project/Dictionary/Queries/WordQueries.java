package com.project.Dictionary.Queries;

import com.project.Dictionary.Constants.WordConstants;

public class WordQueries {
	
	public static final String DELETE_USING_ID = "delete from " + WordConstants.TABLE_NAME + " where " + WordConstants.ID + " =:" + WordConstants.ID; 
}
