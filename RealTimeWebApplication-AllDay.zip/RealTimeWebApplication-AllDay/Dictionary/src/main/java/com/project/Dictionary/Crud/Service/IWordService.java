package com.project.Dictionary.Crud.Service;

import java.util.List;

import com.project.Dictionary.Entities.Word;

public interface IWordService {
	public Word save(Word word);

	public List<Word> getAll();

	public boolean deleteById(int id);

}
