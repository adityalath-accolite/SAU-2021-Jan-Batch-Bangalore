package com.project.Dictionary.Crud.Service.Impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Dictionary.Crud.Service.IWordService;
import com.project.Dictionary.Dao.IWordDao;
import com.project.Dictionary.Entities.Word;

@Service
public class WordService implements IWordService{
	@Autowired
	IWordDao iWordDao;

	@Override
	public Word save(Word word) {
		word.setCreationTm(new Date());
		word.setLastModifiedTm(new Date());
		return iWordDao.save(word);
	}

	@Override
	public List<Word> getAll() {
		return iWordDao.getAll();
	}

	@Override
	public boolean deleteById(int id) {
		if(iWordDao.deleteById(id) > 0)
			return true;
		else
			return false;
	}
	
}
