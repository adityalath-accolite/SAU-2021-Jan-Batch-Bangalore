package com.project.Dictionary.Dao;

import java.util.List;

import com.project.Dictionary.Entities.Word;

public interface IWordDao {
	public Word save(Word word);

	public List<Word> getAll();

	public int deleteById(int id);

}
